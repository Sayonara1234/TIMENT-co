package com.example.timentco;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;

import java.util.List;

public class AgendaAdapter extends RecyclerView.Adapter<AgendaAdapter.AgendaViewHolder> {

    private Context context;
    private List<Agenda> agendaList;
    private DatabaseReference agendaRef;

    public AgendaAdapter(Context context, List<Agenda> agendaList, DatabaseReference agendaRef) {
        this.context = context;
        this.agendaList = agendaList;
        this.agendaRef = agendaRef;
    }

    @NonNull
    @Override
    public AgendaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.agenda_item, parent, false);
        return new AgendaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AgendaViewHolder holder, int position) {
        Agenda agenda = agendaList.get(position);
        holder.bind(agenda);
    }

    @Override
    public int getItemCount() {
        return agendaList.size();
    }

    class AgendaViewHolder extends RecyclerView.ViewHolder {

        private TextView jenisAgendaTextView, lokasiTextView, tanggalTextView;

        public AgendaViewHolder(@NonNull View itemView) {
            super(itemView);
            jenisAgendaTextView = itemView.findViewById(R.id.jenis_agenda);
            lokasiTextView = itemView.findViewById(R.id.lokasi);
            tanggalTextView = itemView.findViewById(R.id.tanggal);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        // Handle item click if needed
                    }
                }
            });
        }

        public void bind(Agenda agenda) {
            jenisAgendaTextView.setText(agenda.getJenisAgenda());
            lokasiTextView.setText("Location: " + agenda.getLokasi());
            tanggalTextView.setText(agenda.getTanggal());
        }
    }
}
