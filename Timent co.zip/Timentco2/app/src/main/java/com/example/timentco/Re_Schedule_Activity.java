package com.example.timentco;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Re_Schedule_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reschedule);
    }

    public void goToAgendaPage(View view) {
        Intent intent = new Intent(this, Home2.class);
        startActivity(intent);
    }

    public void goToJadwalPage(View view) {
        Intent intent = new Intent(this, JadwalPageActivity.class);
        startActivity(intent);
    }

    public void goToRecentPage(View view) {
        Intent intent = new Intent(this, Recent.class);
        startActivity(intent);
    }

    public void profile(View view) {
        Intent intent = new Intent(this, Profile.class);
        startActivity(intent);
    }
}