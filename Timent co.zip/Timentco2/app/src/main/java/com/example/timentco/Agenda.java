package com.example.timentco;

public class Agenda {
    private String jenisAgenda;
    private String lokasi;
    private String tanggal;

    public Agenda() {
        // Default constructor required for calls to DataSnapshot.getValue(Agenda.class)
    }

    public Agenda(String jenisAgenda, String lokasi, String tanggal) {
        this.jenisAgenda = jenisAgenda;
        this.lokasi = lokasi;
        this.tanggal = tanggal;
    }

    public String getJenisAgenda() {
        return jenisAgenda;
    }

    public void setJenisAgenda(String jenisAgenda) {
        this.jenisAgenda = jenisAgenda;
    }

    public String getLokasi() {
        return lokasi;
    }

    public void setLokasi(String lokasi) {
        this.lokasi = lokasi;
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }
}
