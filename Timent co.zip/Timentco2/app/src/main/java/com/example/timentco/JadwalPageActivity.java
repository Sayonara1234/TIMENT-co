package com.example.timentco;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class JadwalPageActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jadwal_page);

    }

    public void goToAgendaPage(View view) {
        Intent intent = new Intent(this, Home2.class);
        startActivity(intent);
    }

    public void goToReschedulePage(View view) {
        Intent intent = new Intent(this, Re_Schedule_Activity.class);
        startActivity(intent);
    }

    public void goToRecentPage(View view) {
        Intent intent = new Intent(this, Recent.class);
        startActivity(intent);
    }

    public void profile(View view) {
        Intent intent = new Intent(this, Profile.class);
        startActivity(intent);
    }
}
