package com.example.timentco;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;

public class add_agenda extends AppCompatActivity {

    private TextInputEditText tanggalEditText; // TextInputEditText for date
    private EditText jenisAgendaEditText, namaEditText, noTelpEditText, lokasiEditText, subjectEditText;
    private Button simpanButton, batalButton;

    private DatabaseReference databaseReference;
    private FirebaseUser currentUser; // Firebase user

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_agenda);

        // Initialize Firebase Database
        databaseReference = FirebaseDatabase.getInstance().getReference();

        // Initialize views
        tanggalEditText = findViewById(R.id.tanggal);
        jenisAgendaEditText = findViewById(R.id.jenis_agenda);
        namaEditText = findViewById(R.id.nama);
        noTelpEditText = findViewById(R.id.no_telp);
        lokasiEditText = findViewById(R.id.lokasi);
        subjectEditText = findViewById(R.id.subject);

        simpanButton = findViewById(R.id.simpan);
        batalButton = findViewById(R.id.batal);

        // Get current Firebase user
        currentUser = FirebaseAuth.getInstance().getCurrentUser();

        // Set OnClickListener for tanggalEditText to show DatePickerDialog
        tanggalEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePicker(); // Call method to show DatePickerDialog
            }
        });

        // Set OnClickListener for Simpan Button
        simpanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                simpanDataKeFirebase(); // Call method to save data to Firebase
            }
        });

        // Set OnClickListener for Batal Button
        batalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Close agenda activity if Batal button is clicked
            }
        });
    }

    // Method to show DatePickerDialog
    private void showDatePicker() {
        // Get current date
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

        // Create DatePickerDialog
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int selectedYear, int monthOfYear, int dayOfMonth) {
                        // Format selected date (e.g., 01/01/2024)
                        String selectedDate = String.format("%02d-%02d-%d", dayOfMonth, monthOfYear + 1, selectedYear);

                        // Set text in tanggalEditText
                        tanggalEditText.setText(selectedDate);
                    }
                },
                year, month, dayOfMonth);

        // Show DatePickerDialog
        datePickerDialog.show();
    }

    // Method to save data to Firebase Realtime Database
    private void simpanDataKeFirebase() {
        // Get values from EditText and TextInputEditText
        String jenisAgenda = jenisAgendaEditText.getText().toString().trim();
        String nama = namaEditText.getText().toString().trim();
        String noTelp = noTelpEditText.getText().toString().trim();
        String lokasi = lokasiEditText.getText().toString().trim();
        String subject = subjectEditText.getText().toString().trim();
        String tanggal = tanggalEditText.getText().toString().trim();

        // Validate input if necessary

        // Check if current user is null
        if (currentUser == null) {
            Toast.makeText(this, "User not authenticated", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get current user's UID or username (change this based on your user management)
        String userId = currentUser.getUid(); // or currentUser.getUsername()

        // Construct database reference path
        DatabaseReference userAgendaRef = databaseReference.child("user").child(userId).child("agenda");

        // Save data directly under 'agenda' node
        userAgendaRef.child("jenis_agenda").setValue(jenisAgenda);
        userAgendaRef.child("nama").setValue(nama);
        userAgendaRef.child("nomor_telepon").setValue(noTelp);
        userAgendaRef.child("lokasi").setValue(lokasi);
        userAgendaRef.child("subjek").setValue(subject);
        userAgendaRef.child("tanggal").setValue(tanggal)
                .addOnSuccessListener(this, aVoid -> {
                    // Reset form after successful save
                    jenisAgendaEditText.setText("");
                    namaEditText.setText("");
                    noTelpEditText.setText("");
                    lokasiEditText.setText("");
                    subjectEditText.setText("");
                    tanggalEditText.setText("");

                    Toast.makeText(add_agenda.this, "Data berhasil disimpan", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(this, e -> {
                    Toast.makeText(add_agenda.this, "Gagal menyimpan data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    // Method to navigate to Profile page
    public void profile(View view) {
        Intent intent = new Intent(this, Profile.class);
        startActivity(intent);
    }

    // Method to go back from Profile page
    public void backprofile(View view) {
        Intent intent = new Intent(this, Home2.class);
        startActivity(intent);
    }
}
