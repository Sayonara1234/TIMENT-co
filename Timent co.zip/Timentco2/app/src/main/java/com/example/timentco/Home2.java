package com.example.timentco;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.view.View;

public class Home2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home2);
        ImageButton buangButton = findViewById(R.id.buang);
    }
    public void goToAgendaPage(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public void goToJadwalPage(View view) {
        Intent intent = new Intent(this, JadwalPageActivity.class);
        startActivity(intent);
    }

    public void goToReschedulePage(View view) {
        Intent intent = new Intent(this, Re_Schedule_Activity.class);
        startActivity(intent);
    }

    public void goToRecentPage(View view) {
        Intent intent = new Intent(this, Recent.class);
        startActivity(intent);
    }
}